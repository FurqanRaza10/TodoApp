const TodoModel = require('../model/task');

// Create and Save a new task
exports.create = async (req, res) => {
    if (!req.body.taskDescription ) {
        return res.status(400).send({ message: "Content cannot be empty!" });
    }

    const todo = new TodoModel({
        title: req.body.taskDescription,
        due: req.body.taskDueDate,
        completed: req.body.completed,
    });

    try {
        const data = await todo.save();
        res.status(201).send({
            message: "Task created successfully!",
            todo: data
        });
    } catch (err) {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the task"
        });
    }
};

// Retrieve all tasks from the database
exports.findAll = async (req, res) => {
    try {
        const todos = await TodoModel.find();
        res.status(200).json(todos);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Find a single task with an id
exports.findOne = async (req, res) => {
    try {
        const todo = await TodoModel.findById(req.params.id);
        if (!todo) {
            return res.status(404).json({ message: "Task not found" });
        }
        res.status(200).json(todo);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Update a task by the id in the request
exports.update = async (req, res) => {
    if (!req.body) {
        return res.status(400).send({ message: "Data to update cannot be empty!" });
    }

    const id = req.params.id;

    try {
        const data = await TodoModel.findByIdAndUpdate(id, req.body, { new: true, useFindAndModify: false });
        if (!data) {
            return res.status(404).send({ message: `Task not found.` });
        }
        res.send({ message: "Task updated successfully.", todo: data });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
};

// Delete a task with the specified id in the request
exports.destroy = async (req, res) => {
    try {
        const data = await TodoModel.findByIdAndRemove(req.params.id, { useFindAndModify: false });
        if (!data) {
            return res.status(404).send({ message: `Task not found.` });
        }
        res.send({ message: "Task deleted successfully!" });
    } catch (err) {
        res.status(500).send({ message: err.message });
    }
};
