var mongoose = require('mongoose');
var schema = new mongoose.Schema({
    taskDescription: {
        type: String,
    },
    taskDue: {
        type: String,
    },
    isCompleted: {
        type: String,
    },
    
});
var task = new mongoose.model('Task', schema);
module.exports = task;